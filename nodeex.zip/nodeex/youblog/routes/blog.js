const express = require('express')
const article = require('../json/article-db.json')
const router = express.Router()

router.get('/',(req,res)=>{
    res.send("ไม่พบหน้าที่ต้องการ")
})

router.get('/:id',(req,res)=>{
    var data ={title :article[req.params.id-1].title+ '| You Blog', article:article[req.params.id-1] }
    res.render('detail',data)

})

module.exports = router 