const express = require('express')
const article = require('../json/article-db.json')
const router = express.Router()

router.get('/', function(req, res, next) {
  if(req.query.search == ""||req.query.search ==null ){
    var searchData = article;
  }else{
    var searchValue = req.query.search;
    var searchData = [];
    article.map((val)=> {
        if(val.title.toLocaleLowerCase().includes(searchValue.toLocaleLowerCase())){
          searchData.push(val)
        }
    })
  }
  var data = { title: 'YouBlog', article: searchData }
  res.render('index', data)

})



module.exports = router 